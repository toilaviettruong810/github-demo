<?php require 'view/header.php'; ?>

<div class="container">
    <h2 class="tieu-de">✏️ Sửa món ăn</h2>

    <div class="form-box">
        <form method="POST" action="index.php?trang=luu_sua_mon">
            <input type="hidden" name="id" value="<?php echo $mon['id']; ?>">

            <div class="nhom">
                <label>Tên món</label>
                <input type="text" name="ten" value="<?php echo $mon['name']; ?>">
            </div>
            <div class="nhom">
                <label>Giá (VNĐ)</label>
                <input type="number" name="gia" value="<?php echo $mon['price']; ?>">
            </div>
            <div class="nhom">
                <label>Loại</label>
                <select name="loai">
                    <?php
                    $loai_list = array('Burger', 'Gà rán', 'Side', 'Pizza', 'Nước', 'Khác');
                    foreach ($loai_list as $loai):
                    ?>
                        <option <?php if ($mon['category'] == $loai) echo 'selected'; ?>>
                            <?php echo $loai; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="nhom">
                <label>Mô tả</label>
                <textarea name="mota"><?php echo $mon['description']; ?></textarea>
            </div>
            <div style="display:flex; gap:10px;">
                <button type="submit" class="nut nut-do">💾 Lưu</button>
                <a href="index.php?trang=quan_ly_mon" class="nut nut-xam">Hủy</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>
