<?php require 'view/header.php'; ?>

<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px;">
        <h2 class="tieu-de" style="margin:0; border:none;">📋 Quản lý món ăn</h2>
        <a href="index.php?trang=them_mon" class="nut nut-do">+ Thêm món</a>
    </div>

    <?php if (isset($_GET['tb']) && $_GET['tb'] == 'them_ok'): ?>
        <div class="thong-bao-ok">✅ Thêm món thành công!</div>
    <?php elseif (isset($_GET['tb']) && $_GET['tb'] == 'sua_ok'): ?>
        <div class="thong-bao-ok">✅ Sửa món thành công!</div>
    <?php elseif (isset($_GET['tb']) && $_GET['tb'] == 'xoa_ok'): ?>
        <div class="thong-bao-ok">🗑️ Đã xóa món!</div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Tên món</th>
                <th>Giá</th>
                <th>Loại</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($danhsach_mon as $mon): ?>
                <tr>
                    <td><?php echo $mon['id']; ?></td>
                    <td><b><?php echo $mon['name']; ?></b></td>
                    <td style="color:#e63946; font-weight:bold;"><?php echo number_format($mon['price']); ?>đ</td>
                    <td><?php echo $mon['category']; ?></td>
                    <td>
                        <a href="index.php?trang=sua_mon&id=<?php echo $mon['id']; ?>" class="nut nut-vang">✏️ Sửa</a>
                        <a href="index.php?trang=xoa_mon&id=<?php echo $mon['id']; ?>"
                           class="nut nut-xam"
                           onclick="return confirm('Xóa món này không?')">🗑️ Xóa</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
