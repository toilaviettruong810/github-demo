<?php require 'view/header.php'; ?>

<div class="khung-dangnhap">
    <div class="hop-dangnhap">
        <h2>📝 Đăng ký</h2>

        <?php if (isset($loi)): ?>
            <div class="thong-bao-loi"><?php echo $loi; ?></div>
        <?php endif; ?>

        <form method="POST" action="index.php?trang=dangky">
            <div class="nhom">
                <label>Tên đăng nhập</label>
                <input type="text" name="username" placeholder="Ít nhất 3 ký tự...">
            </div>
            <div class="nhom">
                <label>Mật khẩu</label>
                <input type="password" name="password" placeholder="Ít nhất 6 ký tự...">
            </div>
            <div class="nhom">
                <label>Nhập lại mật khẩu</label>
                <input type="password" name="password2" placeholder="Nhập lại mật khẩu...">
            </div>
            <div class="nhom">
                <button type="submit" class="nut nut-do">Đăng ký</button>
            </div>
        </form>

        <div style="text-align:center; margin-top:12px; font-size:13px;">
            Đã có tài khoản? <a href="index.php?trang=dangnhap" style="color:#e63946;">Đăng nhập</a>
        </div>
    </div>
</div>

</body>
</html>
