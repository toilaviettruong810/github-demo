<?php require 'view/header.php'; ?>

<div class="container">
    <h2 class="tieu-de">📋 Đơn hàng của tôi</h2>

    <?php if (isset($_GET['tb']) && $_GET['tb'] == 'dat_ok'): ?>
        <div class="thong-bao-ok">✅ Đặt hàng thành công!</div>
    <?php endif; ?>

    <?php if (isset($_GET['tb']) && $_GET['tb'] == 'huy_ok'): ?>
        <div class="thong-bao-loi">✅ Đã hủy đơn hàng!</div>
    <?php endif; ?>

    <?php if (count($danhsach_don) == 0): ?>
        <p style="text-align:center; color:#888; padding:30px;">Bạn chưa có đơn hàng nào.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Thời gian</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Chi tiết</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($danhsach_don as $don): ?>
                    <tr>
                        <td><?php echo $don['id']; ?></td>
                        <td><?php echo $don['created_at']; ?></td>
                        <td style="color:#e63946; font-weight:bold;"><?php echo number_format($don['total']); ?>đ</td>
                        <td>
                            <?php if ($don['status'] == 'cho_xu_ly'): ?>
                                <span class="trang-thai cho">⏳ Chờ xử lý</span>
                            <?php elseif ($don['status'] == 'dang_lam'): ?>
                                <span class="trang-thai lam">🔥 Đang làm</span>
                            <?php elseif ($don['status'] == 'hoan_thanh'): ?>
                                <span class="trang-thai xong">✅ Hoàn thành</span>
                            <?php else: ?>
                                <span class="trang-thai huy">❌ Đã hủy</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="index.php?trang=chi_tiet_don&id=<?php echo $don['id']; ?>" class="nut nut-xanh">Xem</a>

                            <?php if ($don['status'] == 'cho_xu_ly'): ?>
                                <a href="index.php?trang=huy_don&id=<?php echo $don['id']; ?>"
                                   class="nut nut-xam"
                                   onclick="return confirm('Bạn chắc muốn hủy đơn này không?')">❌ Hủy</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>
