<?php require 'view/header.php'; ?>

<div class="container">
    <h2 class="tieu-de">➕ Thêm món mới</h2>

    <div class="form-box">
        <form method="POST" action="index.php?trang=them_mon">
            <div class="nhom">
                <label>Tên món</label>
                <input type="text" name="ten" placeholder="Ví dụ: Burger Bò">
            </div>
            <div class="nhom">
                <label>Giá (VNĐ)</label>
                <input type="number" name="gia" placeholder="Ví dụ: 45000">
            </div>
            <div class="nhom">
                <label>Loại</label>
                <select name="loai">
                    <option>Burger</option>
                    <option>Gà rán</option>
                    <option>Side</option>
                    <option>Pizza</option>
                    <option>Nước</option>
                    <option>Khác</option>
                </select>
            </div>
            <div class="nhom">
                <label>Mô tả</label>
                <textarea name="mota" placeholder="Mô tả ngắn..."></textarea>
            </div>
            <div style="display:flex; gap:10px;">
                <button type="submit" class="nut nut-do">➕ Thêm</button>
                <a href="index.php?trang=quan_ly_mon" class="nut nut-xam">Hủy</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>
