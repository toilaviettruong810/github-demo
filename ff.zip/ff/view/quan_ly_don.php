<?php require 'view/header.php'; ?>

<div class="container">
    <h2 class="tieu-de">📦 Quản lý đơn hàng</h2>

    <?php if (isset($_GET['tb']) && $_GET['tb'] == 'cap_nhat_ok'): ?>
        <div class="thong-bao-ok">✅ Cập nhật trạng thái thành công!</div>
    <?php endif; ?>

    <?php if (count($danhsach_don) == 0): ?>
        <p style="text-align:center; color:#888; padding:30px;">Chưa có đơn hàng nào.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Khách hàng</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Cập nhật</th>
                    <th>Chi tiết</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($danhsach_don as $don): ?>
                    <tr>
                        <td><?php echo $don['id']; ?></td>
                        <td><b><?php echo $don['username']; ?></b></td>
                        <td style="color:#e63946; font-weight:bold;"><?php echo number_format($don['total']); ?>đ</td>
                        <td>
                            <?php if ($don['status'] == 'cho_xu_ly'): ?>
                                <span class="trang-thai cho">⏳ Chờ xử lý</span>
                            <?php elseif ($don['status'] == 'dang_lam'): ?>
                                <span class="trang-thai lam">🔥 Đang làm</span>
                            <?php elseif ($don['status'] == 'hoan_thanh'): ?>
                                <span class="trang-thai xong">✅ Hoàn thành</span>
                            <?php else: ?>
                                <span class="trang-thai huy">❌ Đã hủy</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" action="index.php?trang=cap_nhat_don" style="display:flex; gap:5px;">
                                <input type="hidden" name="order_id" value="<?php echo $don['id']; ?>">
                                <select name="trangthai" style="padding:4px; font-size:13px; border:1px solid #ddd; border-radius:4px;">
                                    <option value="cho_xu_ly"  <?php if ($don['status'] == 'cho_xu_ly')  echo 'selected'; ?>>⏳ Chờ xử lý</option>
                                    <option value="dang_lam"   <?php if ($don['status'] == 'dang_lam')   echo 'selected'; ?>>🔥 Đang làm</option>
                                    <option value="hoan_thanh" <?php if ($don['status'] == 'hoan_thanh') echo 'selected'; ?>>✅ Hoàn thành</option>
                                    <option value="da_huy"     <?php if ($don['status'] == 'da_huy')     echo 'selected'; ?>>❌ Đã hủy</option>
                                </select>
                                <button type="submit" class="nut nut-xanh" style="padding:4px 10px;">Lưu</button>
                            </form>
                        </td>
                        <td>
                            <a href="index.php?trang=chi_tiet_don&id=<?php echo $don['id']; ?>" class="nut nut-xanh">Xem</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>
