<?php require 'view/header.php'; ?>

<div class="container">
    <h2 class="tieu-de">🍔 Thực đơn</h2>

    <?php if (isset($_GET['tb']) && $_GET['tb'] == 'chonmon_ok'): ?>
        <div class="thong-bao-loi">❌ Vui lòng chọn ít nhất 1 món!</div>
    <?php endif; ?>

    <form method="POST" action="index.php?trang=dat_hang">
        <div class="luoi-mon">
            <?php foreach ($danhsach_mon as $mon): ?>
                <div class="the-mon">
                    <div class="bieu-tuong">🍽️</div>
                    <h3><?php echo $mon['name']; ?></h3>
                    <div class="gia"><?php echo number_format($mon['price']); ?>đ</div>
                    <div class="loai"><?php echo $mon['category']; ?></div>
                    <input type="number" name="mon[<?php echo $mon['id']; ?>]" value="0" min="0" max="20">
                </div>
            <?php endforeach; ?>
        </div>

        <div style="text-align:center; margin-top:20px;">
            <button type="submit" class="nut nut-do" style="padding:10px 35px; font-size:15px;">
                🛒 Đặt hàng
            </button>
        </div>
    </form>
</div>

</body>

</html>