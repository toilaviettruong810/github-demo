<?php require 'view/header.php'; ?>

<div class="container">
    <h2 class="tieu-de">📦 Chi tiết đơn hàng</h2>

    <a href="javascript:history.back()" class="nut nut-xam" style="margin-bottom:15px; display:inline-block;">← Quay lại</a>

    <table>
        <thead>
            <tr>
                <th>Tên món</th>
                <th>Đơn giá</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $tong = 0;
            foreach ($chi_tiet as $item):
                $thanhtien = $item['price'] * $item['quantity'];
                $tong += $thanhtien;
            ?>
                <tr>
                    <td><?php echo $item['ten_mon']; ?></td>
                    <td><?php echo number_format($item['price']); ?>đ</td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td><b><?php echo number_format($thanhtien); ?>đ</b></td>
                </tr>
            <?php endforeach; ?>
            <tr style="background:#fff5f5;">
                <td colspan="3" style="text-align:right; font-weight:bold;">Tổng cộng:</td>
                <td style="color:#e63946; font-weight:bold; font-size:16px;"><?php echo number_format($tong); ?>đ</td>
            </tr>
        </tbody>
    </table>
</div>

</body>
</html>
