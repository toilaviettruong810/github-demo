<?php require 'view/header.php'; ?>

<div class="khung-dangnhap">
    <div class="hop-dangnhap">
        <h2>🍔 Đăng nhập</h2>

        <?php if (isset($loi)): ?>
            <div class="thong-bao-loi"><?php echo $loi; ?></div>
        <?php endif; ?>

        <?php if (isset($_GET['tb']) && $_GET['tb'] == 'dangky_ok'): ?>
            <div class="thong-bao-ok">✅ Đăng ký thành công! Hãy đăng nhập.</div>
        <?php endif; ?>

        <form method="POST" action="index.php?trang=dangnhap">
            <div class="nhom">
                <label>Tên đăng nhập</label>
                <input type="text" name="username" placeholder="Nhập tên đăng nhập...">
            </div>
            <div class="nhom">
                <label>Mật khẩu</label>
                <input type="password" name="password" placeholder="Nhập mật khẩu...">
            </div>
            <div class="nhom">
                <button type="submit" class="nut nut-do">Đăng nhập</button>
            </div>
        </form>

        <div style="text-align:center; margin-top:12px; font-size:13px;">
            Chưa có tài khoản? <a href="index.php?trang=dangky" style="color:#e63946;">Đăng ký ngay</a>
        </div>
    </div>
</div>

</body>
</html>
