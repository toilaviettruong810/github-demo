<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>FastFood</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>

<div class="header">
    <h1>🍔 FastFood</h1>
    <?php if (isset($_SESSION['username'])): ?>
        <span>Xin chào, <b><?php echo $_SESSION['username']; ?></b></span>
    <?php endif; ?>
</div>

<?php if (isset($_SESSION['user_id'])): ?>
<div class="nav">
    <?php if ($_SESSION['role'] == 'admin'): ?>
        <a href="index.php?trang=quan_ly_mon">📋 Quản lý món</a>
        <a href="index.php?trang=quan_ly_don">📦 Quản lý đơn</a>
    <?php else: ?>
        <a href="index.php?trang=menu">🍟 Đặt đồ ăn</a>
        <a href="index.php?trang=don_hang">📋 Đơn của tôi</a>
    <?php endif; ?>
    <a href="index.php?trang=danxuat" style="margin-left:auto;">🚪 Đăng xuất</a>
</div>
<?php endif; ?>
