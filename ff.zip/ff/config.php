<?php
$conn = mysqli_query("localhost", "root", "", "fastfood");

if (!$conn) {
    die("loi he thong :" . mysqli_connect_error());
} else {
    echo "ket noi thanh cong";
}
