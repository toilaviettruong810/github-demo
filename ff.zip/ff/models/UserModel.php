<?php
// Lấy thông tin user theo tên đăng nhập
function timUser($conn, $username) {
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);
    return mysqli_fetch_assoc($result);
}

// Kiểm tra đăng nhập
function dangNhap($conn, $username, $password) {
    $user = timUser($conn, $username);
    if ($user && password_verify($password, $user['password'])) {
        return $user;
    }
    return false;
}

// Đăng ký tài khoản mới
function dangKy($conn, $username, $password) {
    // Kiểm tra username đã tồn tại chưa
    $user = timUser($conn, $username);
    if ($user) {
        return false; // Đã tồn tại
    }

    $matkhau = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$matkhau', 'customer')";
    return mysqli_query($conn, $sql);
}
?>
