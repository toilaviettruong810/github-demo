<?php
// Tạo đơn hàng mới, trả về ID vừa tạo
function taoDoHang($conn, $user_id, $tongtien) {
    $sql = "INSERT INTO orders (user_id, total) VALUES ($user_id, $tongtien)";
    mysqli_query($conn, $sql);
    return mysqli_insert_id($conn); // ID của đơn vừa tạo
}

// Thêm từng món vào đơn hàng
function themMonVaoDon($conn, $order_id, $food_id, $soluong, $gia) {
    $sql = "INSERT INTO order_items (order_id, food_id, quantity, price) VALUES ($order_id, $food_id, $soluong, $gia)";
    return mysqli_query($conn, $sql);
}

// Lấy đơn hàng của 1 khách
function layDonCuaToi($conn, $user_id) {
    $sql = "SELECT * FROM orders WHERE user_id = $user_id ORDER BY created_at DESC";
    $result = mysqli_query($conn, $sql);

    $danhsach = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $danhsach[] = $row;
    }
    return $danhsach;
}

// Lấy tất cả đơn hàng (admin)
function layTatCaDon($conn) {
    $sql = "SELECT orders.*, users.username FROM orders JOIN users ON orders.user_id = users.id ORDER BY orders.created_at DESC";
    $result = mysqli_query($conn, $sql);

    $danhsach = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $danhsach[] = $row;
    }
    return $danhsach;
}

// Lấy chi tiết món trong 1 đơn
function layChiTietDon($conn, $order_id) {
    $sql = "SELECT order_items.*, foods.name as ten_mon FROM order_items JOIN foods ON order_items.food_id = foods.id WHERE order_id = $order_id";
    $result = mysqli_query($conn, $sql);

    $danhsach = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $danhsach[] = $row;
    }
    return $danhsach;
}

// Cập nhật trạng thái đơn (admin)
function capNhatTrangThai($conn, $order_id, $trangthai) {
    $sql = "UPDATE orders SET status='$trangthai' WHERE id=$order_id";
    return mysqli_query($conn, $sql);
}
?>
