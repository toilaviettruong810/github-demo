<?php
// Lấy tất cả món ăn
function layTatCaMon($conn) {
    $sql = "SELECT * FROM foods ORDER BY category, name";
    $result = mysqli_query($conn, $sql);

    $danhsach = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $danhsach[] = $row;
    }
    return $danhsach;
}

// Lấy 1 món theo ID
function layMonTheoId($conn, $id) {
    $sql = "SELECT * FROM foods WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    return mysqli_fetch_assoc($result);
}

// Thêm món mới
function themMon($conn, $ten, $gia, $loai, $mota) {
    $sql = "INSERT INTO foods (name, price, category, description) VALUES ('$ten', $gia, '$loai', '$mota')";
    return mysqli_query($conn, $sql);
}

// Sửa món ăn
function suaMon($conn, $id, $ten, $gia, $loai, $mota) {
    $sql = "UPDATE foods SET name='$ten', price=$gia, category='$loai', description='$mota' WHERE id=$id";
    return mysqli_query($conn, $sql);
}

// Xóa món ăn
function xoaMon($conn, $id) {
    $sql = "DELETE FROM foods WHERE id = $id";
    return mysqli_query($conn, $sql);
}
?>
