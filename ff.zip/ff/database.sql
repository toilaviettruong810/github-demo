-- Tạo database
CREATE DATABASE IF NOT EXISTS fastfood;
USE fastfood;

-- Bảng người dùng
-- id: số thứ tự tự tăng
-- username: tên đăng nhập, không được trùng
-- password: mật khẩu đã được mã hóa
-- role: vai trò, chỉ có 2 loại là admin hoặc customer
-- created_at: tự động lưu thời gian tạo
CREATE TABLE users (
    id           INT           AUTO_INCREMENT PRIMARY KEY,
    username     VARCHAR(50)   NOT NULL UNIQUE,
    password     VARCHAR(255)  NOT NULL,
    role         VARCHAR(10)   DEFAULT 'customer',
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- Bảng món ăn
-- id: số thứ tự tự tăng
-- name: tên món
-- price: giá tiền
-- category: loại món (Burger, Gà rán, Nước...)
-- description: mô tả ngắn
CREATE TABLE foods (
    id           INT           AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100)  NOT NULL,
    price        INT           NOT NULL,
    category     VARCHAR(50),
    description  TEXT,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- Bảng đơn hàng
-- id: số thứ tự tự tăng
-- user_id: ai đặt (liên kết sang bảng users)
-- total: tổng tiền của đơn
-- status: trạng thái đơn hàng
-- created_at: thời gian đặt hàng
CREATE TABLE orders (
    id           INT           AUTO_INCREMENT PRIMARY KEY,
    user_id      INT,
    total        INT           NOT NULL,
    status       VARCHAR(20)   DEFAULT 'cho_xu_ly',
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Bảng chi tiết đơn hàng
-- Mỗi dòng là 1 món trong đơn
-- order_id: thuộc đơn hàng nào (liên kết sang bảng orders)
-- food_id: món ăn nào (liên kết sang bảng foods)
-- quantity: số lượng
-- price: giá tại thời điểm đặt
CREATE TABLE order_items (
    id           INT  AUTO_INCREMENT PRIMARY KEY,
    order_id     INT,
    food_id      INT,
    quantity     INT  NOT NULL,
    price        INT  NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (food_id)  REFERENCES foods(id)
);

-- Tài khoản admin mặc định (mật khẩu: password)
INSERT INTO users (username, password, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Dữ liệu món ăn mẫu
INSERT INTO foods (name, price, category, description) VALUES
('Burger Bò',      45000, 'Burger',  'Burger bò tươi, phô mai, rau'),
('Burger Gà',      40000, 'Burger',  'Gà chiên giòn, sốt mayo'),
('Khoai Tây Chiên',25000, 'Side',    'Khoai tây chiên vàng giòn'),
('Gà Rán 3 Miếng', 55000, 'Gà rán', 'Gà rán giòn gia vị đặc biệt'),
('Pepsi',          15000, 'Nước',    'Pepsi lạnh 500ml'),
('Trà Chanh',      15000, 'Nước',    'Trà chanh tươi mát'),
('Pizza Nhỏ',      65000, 'Pizza',   'Pizza 6 miếng phô mai');