<?php
session_start();
require_once 'config.php';
require_once 'controllers/AuthController.php';
require_once 'controllers/FoodController.php';
require_once 'controllers/OrderController.php';

// Lấy tên trang từ URL, mặc định là dangnhap
$trang = isset($_GET['trang']) ? $_GET['trang'] : 'dangnhap';
if ($trang == '') {
    $trang = 'dangnhap';
}

// Kiểm tra đăng nhập — nếu chưa đăng nhập thì về trang đăng nhập
$can_dangnhap = array('menu', 'don_hang', 'dat_hang', 'quan_ly_mon', 'them_mon', 'sua_mon', 'xoa_mon', 'luu_sua_mon', 'quan_ly_don', 'cap_nhat_don', 'chi_tiet_don', 'huy_don');

if (in_array($trang, $can_dangnhap)) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php?trang=dangnhap");
        exit;
    }
}

// Kiểm tra quyền admin
$chi_admin = array('quan_ly_mon', 'them_mon', 'sua_mon', 'xoa_mon', 'luu_sua_mon', 'quan_ly_don', 'cap_nhat_don');

if (in_array($trang, $chi_admin)) {
    if ($_SESSION['role'] != 'admin') {
        header("Location: index.php?trang=menu");
        exit;
    }
}

// Điều hướng đến đúng chức năng
if ($trang == 'dangnhap') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        xuLyDangNhap($conn);
    } else {
        require 'view/dangnhap.php';
    }
} else if ($trang == 'dangky') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        xuLyDangKy($conn);
    } else {
        require 'view/dangky.php';
    }
} else if ($trang == 'danxuat') {
    session_destroy();
    header("Location: index.php?trang=dangnhap");
    exit;
} else if ($trang == 'menu') {
    hienThiMenu($conn);
} else if ($trang == 'dat_hang') {
    xuLyDatHang($conn);
} else if ($trang == 'don_hang') {
    hienThiDonCuaToi($conn);
} else if ($trang == 'chi_tiet_don') {
    hienThiChiTiet($conn);
} else if ($trang == 'quan_ly_mon') {
    hienThiQuanLyMon($conn);
} else if ($trang == 'them_mon') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        xuLyThemMon($conn);
    } else {
        require 'view/them_mon.php';
    }
} else if ($trang == 'sua_mon') {
    hienThiSuaMon($conn);
} else if ($trang == 'luu_sua_mon') {
    xuLySuaMon($conn);
} else if ($trang == 'xoa_mon') {
    xuLyXoaMon($conn);
} else if ($trang == 'quan_ly_don') {
    hienThiQuanLyDon($conn);
} else if ($trang == 'cap_nhat_don') {
    xuLyCapNhatTrangThai($conn);
} else if ($trang == 'huy_don') {
    $id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    $sql = "UPDATE orders SET status='da_huy' WHERE id=$id AND user_id=$user_id AND status='cho_xu_ly'";
    mysqli_query($conn, $sql);
    header("Location: index.php?trang=don_hang&tb=huy_ok");
    exit;
} else {
    echo "<h2>Trang không tồn tại</h2>";
    echo "<a href='index.php'>Về trang chủ</a>";
}
