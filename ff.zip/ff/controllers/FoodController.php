<?php
require_once 'models/FoodModel.php';

// Hiển thị menu cho khách
function hienThiMenu($conn) {
    $danhsach_mon = layTatCaMon($conn);
    require 'view/menu.php';
}

// Hiển thị trang quản lý món (admin)
function hienThiQuanLyMon($conn) {
    $danhsach_mon = layTatCaMon($conn);
    require 'view/quan_ly_mon.php';
}

// Xử lý thêm món
function xuLyThemMon($conn) {
    $ten  = $_POST['ten'];
    $gia  = $_POST['gia'];
    $loai = $_POST['loai'];
    $mota = $_POST['mota'];

    themMon($conn, $ten, $gia, $loai, $mota);
    header("Location: index.php?trang=quan_ly_mon&tb=them_ok");
    exit;
}

// Hiển thị form sửa món
function hienThiSuaMon($conn) {
    $id  = $_GET['id'];
    $mon = layMonTheoId($conn, $id);
    require 'view/sua_mon.php';
}

// Xử lý sửa món
function xuLySuaMon($conn) {
    $id   = $_POST['id'];
    $ten  = $_POST['ten'];
    $gia  = $_POST['gia'];
    $loai = $_POST['loai'];
    $mota = $_POST['mota'];

    suaMon($conn, $id, $ten, $gia, $loai, $mota);
    header("Location: index.php?trang=quan_ly_mon&tb=sua_ok");
    exit;
}

// Xử lý xóa món
function xuLyXoaMon($conn) {
    $id = $_GET['id'];
    xoaMon($conn, $id);
    header("Location: index.php?trang=quan_ly_mon&tb=xoa_ok");
    exit;
}
?>
