<?php
require_once 'models/OrderModel.php';
require_once 'models/FoodModel.php';

// Xử lý đặt hàng
function xuLyDatHang($conn) {
    $user_id = $_SESSION['user_id'];
    $danhsach_chon = $_POST['mon']; // mảng: mon[id] = so_luong

    $tongtien = 0;
    foreach ($danhsach_chon as $food_id => $soluong) {
        if ($soluong > 0) {
            $mon = layMonTheoId($conn, $food_id);
            $tongtien += $mon['price'] * $soluong;
        }
    }

    if ($tongtien == 0) {
        header("Location: index.php?trang=menu&tb=chon_mon");
        exit;
    }

    // Tạo đơn hàng
    $order_id = taoDoHang($conn, $user_id, $tongtien);

    // Thêm từng món vào đơn
    foreach ($danhsach_chon as $food_id => $soluong) {
        if ($soluong > 0) {
            $mon = layMonTheoId($conn, $food_id);
            themMonVaoDon($conn, $order_id, $food_id, $soluong, $mon['price']);
        }
    }

    header("Location: index.php?trang=don_hang&tb=dat_ok");
    exit;
}

// Hiển thị đơn hàng của khách
function hienThiDonCuaToi($conn) {
    $user_id    = $_SESSION['user_id'];
    $danhsach_don = layDonCuaToi($conn, $user_id);
    require 'view/don_hang.php';
}

// Hiển thị tất cả đơn (admin)
function hienThiQuanLyDon($conn) {
    $danhsach_don = layTatCaDon($conn);
    require 'view/quan_ly_don.php';
}

// Xem chi tiết đơn
function hienThiChiTiet($conn) {
    $order_id   = $_GET['id'];
    $chi_tiet   = layChiTietDon($conn, $order_id);
    require 'view/chi_tiet_don.php';
}

// Admin cập nhật trạng thái
function xuLyCapNhatTrangThai($conn) {
    $order_id   = $_POST['order_id'];
    $trangthai  = $_POST['trangthai'];
    capNhatTrangThai($conn, $order_id, $trangthai);
    header("Location: index.php?trang=quan_ly_don&tb=cap_nhat_ok");
    exit;
}
?>
