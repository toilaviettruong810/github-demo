<?php
require_once 'models/UserModel.php';

// Xử lý đăng nhập
function xuLyDangNhap($conn) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $user = dangNhap($conn, $username, $password);

    if ($user) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];

        if ($user['role'] == 'admin') {
            header("Location: index.php?trang=quan_ly_mon");
        } else {
            header("Location: index.php?trang=menu");
        }
        exit;
    } else {
        $loi = "Sai tên đăng nhập hoặc mật khẩu!";
        require 'view/dangnhap.php';
    }
}

// Xử lý đăng ký
function xuLyDangKy($conn) {
    $username  = $_POST['username'];
    $password  = $_POST['password'];
    $password2 = $_POST['password2'];

    if (strlen($username) < 3) {
        $loi = "Tên đăng nhập phải có ít nhất 3 ký tự!";
        require 'view/dangky.php';
        return;
    }

    if (strlen($password) < 6) {
        $loi = "Mật khẩu phải có ít nhất 6 ký tự!";
        require 'view/dangky.php';
        return;
    }

    if ($password != $password2) {
        $loi = "Mật khẩu nhập lại không khớp!";
        require 'view/dangky.php';
        return;
    }

    $ok = dangKy($conn, $username, $password);

    if ($ok) {
        header("Location: index.php?trang=dangnhap&tb=dangky_ok");
        exit;
    } else {
        $loi = "Tên đăng nhập đã tồn tại!";
        require 'view/dangky.php';
    }
}
?>
